 /*---------------------------------------------------------------------------
;
;

;
;---------------------------------------------------------------------------*/
#define SYSCLK 22118400 //approximate SYSCLK frequency in Hz
#define BAUDRATE  115200L          // Baud rate of UART in bps
                                   // Le caract�re 'L' force l'�valuation de BAUDRATE en entier long
//#define TICK_CLK  200  // (en hertz)

                                                        // 
